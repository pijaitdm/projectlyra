// isi menu
#include <iostream>
#include <string>

void  batas(){
  std::string garis = "=";
  for (int i = 0 ; i < 30; ++i){
  std::cout << garis;
  }
  std::cout << std::endl ;
}

void drawBox(const std::string& text) {
    int width = text.length() + 4;
    std::string horizontal = "═";

    std::cout << "╔";
    for (int i = 0; i < width; ++i) std::cout << horizontal;
    std::cout << "╗" << std::endl;

    std::cout << "║  " << text << "  ║" << std::endl;

    std::cout << "╚";
    for (int i = 0; i < width; ++i) std::cout << horizontal;
    std::cout << "╝" << std::endl;
}

void pilih_menu(){
  std::string menu_arr [] ={
  " 1. input UE LCR", 
  " 2. Update",
  " 8. clear ", 
  " 9. lihat menu", 
  " 0. Keluar"};

  int t_e = sizeof (menu_arr) / sizeof  (menu_arr[0]);
  for (int i = 0 ; i < t_e ; ++i){
    std::cout << menu_arr[i] <<std::endl;
    };
}

// menu eksekusi
void menu(){
  drawBox("Project LYRA LCR");
  batas();
  pilih_menu();
  batas();
}





