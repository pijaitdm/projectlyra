#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <filesystem>

namespace fs = std::filesystem;

int main() {
    std::string folder_path = "data"; // Lokasi folder CSV
    int total_kolom2 = 0;

    if (!fs::exists(folder_path)) {
        std::cerr << "Folder tidak ditemukan.\n";
        return 1;
    }

    for (const auto& entry : fs::directory_iterator(folder_path)) {
        if (entry.path().extension() == ".csv") {
            std::ifstream file(entry.path());
            if (!file) {
                std::cerr << "Gagal membuka: " << entry.path() << std::endl;
                continue;
            }

            std::string line;
            while (std::getline(file, line)) {
                std::stringstream ss(line);
                std::string kolom1, kolom2;

                if (std::getline(ss, kolom1, ',') && std::getline(ss, kolom2)) {
                    try {
                        total_kolom2 += std::stoi(kolom2);
                    } catch (...) {
                        std::cerr << "Baris tidak valid di file: " << entry.path() << std::endl;
                    }
                }
            }
        }
    }

    std::cout << "Total dari semua kolom ke-2: " << total_kolom2 << std::endl;
    return 0;
}

