#ifndef MENU_HPP
#define MENU_HPP

void menu();
void pilih_menu();
void batas();


#endif

