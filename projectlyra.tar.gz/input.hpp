#ifndef INPUT_HPP
#define INPUT_HPP

int userInput(const std::string& pesan);
std::string tambah_bulan(std::string par_bulan);

#endif

