#ifndef PILIH1_HPP
#define	PILIH1_HPP

void pilihan1();

#endif
